CREATE TABLE car (id INTEGER PRIMARY KEY, type TEXT, name TEXT, description TEXT, urlPhoto TEXT, urlVideo TEXT, latitude TEXT, longitude TEXT);
CREATE TABLE favorite_car (id INTEGER PRIMARY KEY);