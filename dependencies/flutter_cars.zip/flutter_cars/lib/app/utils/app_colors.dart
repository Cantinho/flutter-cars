

import 'package:flutter/material.dart';

blendedRed() {
  return Color.alphaBlend(Colors.black38, Colors.pink);
}

white() {
  return Colors.white;
}

blendedBlack() {
  return Color.alphaBlend(Colors.black54, Colors.black38);
}