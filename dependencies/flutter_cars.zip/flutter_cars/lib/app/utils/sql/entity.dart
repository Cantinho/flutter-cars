

abstract class Entity {

  Map<String, dynamic> toMap();

}